assert new File(basedir, 'target/it/ftp-download/README').exists();
